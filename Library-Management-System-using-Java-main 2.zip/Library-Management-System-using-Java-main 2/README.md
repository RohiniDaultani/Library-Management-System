# Library Management System

## About Project:
A Library Management System  allows you to keep the Library book records, Library student records and manage them when needed. This is a simple java project with a good and interactive-looking GUI. This Project Use MySQL Database for managing all the data that store in the database.The Library Management System Project In Java And MySQL is simple and basic level small project for learning purposes. Also, you can modify this system as per your requirements and develop a perfect advance level project.


## Available Modules:

1. Login/ Logout Module
2. Account Management
3. Manage Books
4. Manage Students
5. Issue Book
6. Return Book
7. View Records
8. About project

